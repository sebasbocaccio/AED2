# Lo Bueno
* Buen uso de axiomatización
* Dominio de escritura de TADs

# Para Charlar
* Sobre delegación / TADs estilo programación

# Para Corregir
* No se modelan ríos infinitos
* El nivel de los comercios no tiene en cuenta el nivel de las casas
(Están los andamios pero la especificación no cierra)
* Problemas de recursión en casos de pasarNivel
