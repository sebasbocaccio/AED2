# TAD Comercio
* Curioso el cambio de casilla y nivel

# TAD Mapa
* Los ríos se agregan junto con las casas y comercios. Deben estár definidos
    al principio.
* Los ríos no son líneas horizontales o verticales infinitas.

# TAD Partida
* No pusieron restricción de que no se pisen construcciones de nivel máximo
    al unir partidas pero lo resolvieron en las consideraciones.
