#include "aed2_Mapa.h"

// Completar


aed2_Mapa::aed2_Mapa(): _mapa(MapaTP({}, {})) {
}


void aed2_Mapa::agregarRio(Direccion d, int p){
    this->_mapa.agregarRio(d,p);
}

aed2_Mapa::aed2_Mapa(MapaTP m): _mapa(m){
}

Mapa aed2_Mapa::mapa(){
    return _mapa;
}

void aed2_Mapa::unirMapa(aed2_Mapa m2){
    this->_mapa.unirMapa(m2.mapa());
}

bool aed2_Mapa::hayRio(Casilla c) const{
    this->_mapa.hayRio(c);
}

