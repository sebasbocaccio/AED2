#include "aed2_SimCity.h"

aed2_SimCity::aed2_SimCity(aed2_Mapa m) : _simcity(SimCity(m.mapa())){}

SimCity aed2_SimCity::simCity(){
    return _simcity;
}

void aed2_SimCity::agregarCasa(Casilla c){
    _simcity.agregarCasa(c);
}
void aed2_SimCity::agregarComercio(Casilla c){
    _simcity.agregarComercio(c);
}

void aed2_SimCity::avanzarTurno(){
    _simcity.avanzarTurno();
}
void aed2_SimCity::unir(aed2_SimCity sc){
    _simcity.unir(sc.simCity());
}

Mapa aed2_SimCity::mapa(){
   return _simcity.Mapa();
}

set<Casilla> aed2_SimCity::comercios(){
    return _simcity.Comercios();
}

set<Casilla> aed2_SimCity::casas(){
    return _simcity.Casas();
}

Nat aed2_SimCity::popularidad() const {
    return _simcity.popularidad();
}

Nat aed2_SimCity::antiguedad() const {
    return _simcity.antiguedad();
}

bool aed2_SimCity::huboConstruccion() const {
    return _simcity.huboConstruccion();
}

Nat aed2_SimCity::nivel(Casilla c) const {
    return _simcity.nivelCasilla(c);
}
