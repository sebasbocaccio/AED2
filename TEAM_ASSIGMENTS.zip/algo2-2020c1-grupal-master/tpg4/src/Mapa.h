
#ifndef TP3_SIMCITY_MAPA_H
#define TP3_SIMCITY_MAPA_H

#include "Tipos.h"
#include <list>



class MapaTP {
public:
    MapaTP(list<int> hs, list<int> vs);

    list<int> horizontales();

    list<int> verticales();

    void agregarRio(Direccion d, int p);

    bool hayRio(Casilla c) const;

    void unirMapa(MapaTP m2);

private:

    list<int> _horizontales;

    list<int> _verticales;

};




#endif //TP3_SIMCITY_MAPA_H
