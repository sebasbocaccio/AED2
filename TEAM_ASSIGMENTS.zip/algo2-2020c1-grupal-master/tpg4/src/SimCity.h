//
// Created by martin on 1/7/20.
//

#ifndef TP3_SIMCITY_SIMCITY_H
#define TP3_SIMCITY_SIMCITY_H
#include <cmath>
#include "Mapa.h"
#include "Tipos.h"
#include <list>
#include <set>

using construccion = pair<Casilla, unsigned int>;

class SimCityTP{
public:

    SimCityTP(MapaTP mapa);

    MapaTP Mapa();

    set<Casilla> Casas();

    set<Casilla> Comercios();

    void agregarCasa(Casilla c);

    void agregarComercio(Casilla c);

    void avanzarTurno();

    void unir(SimCityTP sc);

    bool huboConstruccion() const;

    unsigned int nivelCasilla(Casilla c) const;

    unsigned int popularidad() const;

    unsigned int antiguedad() const;



private:


    list<construccion> _casas;
    list<construccion> _comercios;
    MapaTP _mapa;
    bool _huboconstruccion;
    unsigned int _turno;
    unsigned int _popularidad;

    int nivelManhattan(construccion comercio) const;

};

#endif //TP3_SIMCITY_SIMCITY_H
