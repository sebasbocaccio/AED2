
#include "SimCity.h"

SimCityTP::SimCityTP(MapaTP mapa): _mapa(mapa), _casas(),_comercios(), _turno(0), _popularidad(0),_huboconstruccion(false){}

void SimCityTP::agregarCasa(Casilla c){
    _casas.push_back(make_pair(c, 0)); //Suponemos que agregar elemento es O(1)
    _huboconstruccion = true; // O(1)
}

void SimCityTP::agregarComercio(Casilla c) {
    _comercios.push_back((make_pair(c,0))); //Suponemos que agregar elemento es O(1)
    _huboconstruccion = true; // O(1)
}

void quitarCasillasRepetidas(list<construccion>& casillas){
    list<construccion>::iterator it = casillas.begin();
    for (int i = 0; i < casillas.size(); ++i) {
        list<construccion>::iterator it2 = casillas.begin();
        for (int j = 0; j < i; ++j) {
            if(it->first == it2->first && it != it2){
                if (it->second >= it2->second ){
                    casillas.erase(it2++);
                    it--;
                } else{
                    it->second = it2->second;
                    casillas.erase(it2++);
                    it--;
                }
            } else{
                it2++;
            }
        }
        it++;
    }
}
//list<construccion>::iterator iteratorLimpio(int pos, list<construccion>& casillas){
//
//}


void casasYComerciosNoRepetidos(list<construccion> &casas, list<construccion> &comercios) {
    list<construccion>::iterator itCasas = casas.begin();
    while (itCasas != casas.end()) {
        list<construccion>::iterator itComercios = comercios.begin();
        while (itComercios != comercios.end()) {
            if (itCasas->first == itComercios->first) {
                comercios.erase(itComercios++);
            } else {
                itComercios++;
            }
        }
        itCasas++;
    }
}

set<Casilla> SimCityTP::Casas() {
    quitarCasillasRepetidas(_casas);
    casasYComerciosNoRepetidos(_casas, _comercios);
    set<Casilla> casas;
    for(construccion c: _casas){
        casas.insert(c.first);
    }
    return casas;
}
void SimCityTP::avanzarTurno() {
      _turno++;
    _huboconstruccion = false;
    list<construccion>::iterator itCasas ;
    for(itCasas = _casas.begin() ; itCasas != _casas.end();itCasas++){
        itCasas->second ++;
    }
    list<construccion>::iterator itComercios ;
    for(itComercios = _comercios.begin(); itComercios != _comercios.end() ; itComercios++ ){
        itComercios->second++;
    }
}

unsigned int SimCityTP::popularidad() const { // O(1)
    return _popularidad;
}

unsigned int SimCityTP::antiguedad() const {
    return _turno;
}

unsigned int SimCityTP::nivelCasilla(Casilla c) const {
  list<construccion> casas = _casas;
    list<construccion> comercios = _comercios;
    quitarCasillasRepetidas(casas);
    quitarCasillasRepetidas(comercios);
    casasYComerciosNoRepetidos(casas,comercios);
    for(construccion x : casas){
        if(x.first == c) return x.second;
    }
    for(construccion x : comercios){
        if(x.first == c) {
            if(nivelManhattan(x) <= x.second) return x.second;
            else return nivelManhattan(x);
        }
    }
    return 0;
}
int SimCityTP::nivelManhattan(construccion comercio ) const {
    _List_const_iterator<pair<pair<int, int>, unsigned int>> iteradorCasas = _casas.begin();
    int maximo = 0;
    for(int i = 0 ; i < _casas.size(); i++){// Supongo que lo _casas.size() es O(1)
        if( abs(abs(iteradorCasas->first.first - comercio.first.first) + abs(iteradorCasas->first.second - comercio.first.second)) <= 3){
            if(iteradorCasas->second > maximo){
                maximo = iteradorCasas->second;
            }
        }
        iteradorCasas++;
    }
    return maximo;
}
void SimCityTP::unir(SimCityTP sc){
    _casas.splice(_casas.end(),sc._casas); // Suponemos operacion splice es O(1). Seria unir 2 punteros
    _mapa.unirMapa(sc.Mapa());  // O(1)
    _comercios.splice(_comercios.end(),sc._comercios); // Suponemos operacion splice es O(1). Seria unir 2 punteros
    _huboconstruccion = _huboconstruccion || sc._huboconstruccion; // O(1)
    _popularidad = _popularidad + sc._popularidad + 1; // O(1)
    _turno = max(_turno, sc._turno); // O(1)
} // O(1)
MapaTP SimCityTP::Mapa(){
    return _mapa;
}

set<Casilla> SimCityTP::Comercios() {
    quitarCasillasRepetidas(this->_casas);
    quitarCasillasRepetidas(this->_comercios);
    casasYComerciosNoRepetidos(this->_casas,this->_comercios);
    set<Casilla> comercios;
    for(construccion c: this->_comercios){
        comercios.insert(c.first);
    }
    return comercios;
}


bool SimCityTP::huboConstruccion() const{
    return _huboconstruccion;
}

