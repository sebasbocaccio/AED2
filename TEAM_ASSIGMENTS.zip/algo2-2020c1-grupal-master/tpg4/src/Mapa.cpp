#include "Mapa.h"

MapaTP::MapaTP(list<int> hs, list<int> vs): _horizontales(hs), _verticales(vs){}


void MapaTP::unirMapa(MapaTP m2) {
    _horizontales.splice(_horizontales.end(), m2._horizontales); //Suponemos operacion splice es O(1). Seria unir 2 punteros
    _verticales.splice(_verticales.end(), m2._verticales); // Suponemos operacion splice es O(1). Seria unir 2 punteros
}

void MapaTP::agregarRio(Direccion d, int  p){
    if(d == Horizontal){
        _horizontales.push_back(p);
    } else(_verticales.push_back(p));
}

bool MapaTP::hayRio(Casilla c) const{
    for(int x : _horizontales){
        if(x == c.second) return true;
    }
    for(int x : _verticales){
        if(x == c.first) return true;
    }
    return false;
}

list<int> MapaTP::horizontales() {
    return _horizontales;
}

list<int> MapaTP::verticales() {
    return _verticales;
}
