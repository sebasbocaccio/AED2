#ifndef TIPOS_H
#define TIPOS_H
#include <utility>

#include <utility>
using namespace std;

using Casilla = pair<int, int>;
enum Direccion {
    Horizontal, Vertical
};


#endif
