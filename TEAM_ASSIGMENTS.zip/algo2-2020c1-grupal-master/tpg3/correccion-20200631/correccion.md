# Mapa

## Interfaz
* AgregarRio no es O(1)

## Abs
* Parecería usarse una función de implementación

# SimCity

## Abs
* Se usan funciones de implementación
